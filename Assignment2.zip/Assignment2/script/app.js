var apiKey = "4cc0468a068e44be6aab29e6409ea50b",
  basePath = "https://image.tmdb.org/t/p/w185_and_h278_bestv2",
  youtubeBaseUrl = "https://www.youtube.com/embed/";

function toggleNavbar() {
  var navbar = document.getElementById("myTopnav");

  navbar.className === "topnav"
    ? (navbar.className += " responsive")
    : (navbar.className = "topnav");
}

function createMovieBox(movie) {
  let element = document.createElement("div");
  element.className = "col-4";

  let cardView = document.createElement("div");
  cardView.className = "card-view";
  element.appendChild(cardView);

  // 01
  let cardHeader = document.createElement("div");
  cardHeader.className = "card-header";
  cardHeader.style.background = "url(" + basePath + movie.poster_path + ")";
  cardView.appendChild(cardHeader);

  let cardHeaderIcon = document.createElement("div");
  cardHeaderIcon.className = "card-header-icon";
  cardHeader.appendChild(cardHeaderIcon);

  let imageLink = document.createElement("a");
  imageLink.href = "/movieDetail.html?movieId=" + movie.id;
  cardHeaderIcon.appendChild(imageLink);

  let playIcon = document.createElement("i");
  playIcon.className = "fa fa-play header-icon";
  imageLink.appendChild(playIcon);

  // 02
  let cardMovieContent = document.createElement("div");
  cardMovieContent.className = "card-movie-content";
  cardView.appendChild(cardMovieContent);

  // 02 - 01
  let cardMovieContentHead = document.createElement("div");
  cardMovieContentHead.className = "card-movie-content-head";
  cardMovieContent.appendChild(cardMovieContentHead);

  let imageLink2 = document.createElement("a");
  imageLink2.href = "/movieDetail.html?movieId=" + movie.id;
  cardMovieContentHead.appendChild(imageLink2);

  let cardMovieTitle = document.createElement("h3");
  cardMovieTitle.className = "card-movie-title";
  cardMovieTitle.innerText = movie.title;
  cardMovieTitle.title = movie.title;
  imageLink2.appendChild(cardMovieTitle);

  let ratings = document.createElement("div");
  ratings.className = "ratings";
  cardMovieContentHead.appendChild(ratings);

  let ratingSpan = document.createElement("span");
  ratingSpan.innerText = movie.vote_average;
  ratings.appendChild(ratingSpan);

  let ratingTotalSpan = document.createElement("div");
  ratingTotalSpan.style.display = "inline";
  ratingTotalSpan.innerText = " / 10";
  ratings.appendChild(ratingTotalSpan);

  // 02 - 02
  let movieCardInfo = document.createElement("div");
  movieCardInfo.className = "card-movie-info";
  cardMovieContent.appendChild(movieCardInfo);

  // 02 - 02 - 01
  let movieCardInfoDetail1 = document.createElement("div");
  movieCardInfoDetail1.className = "movie-card-info-detail";
  movieCardInfo.appendChild(movieCardInfoDetail1);

  let movieCardInfoDetail1Label = document.createElement("label");
  movieCardInfoDetail1Label.innerText = "Release Date";
  movieCardInfoDetail1.appendChild(movieCardInfoDetail1Label);

  let movieCardInfoDetail1Span = document.createElement("span");
  movieCardInfoDetail1Span.innerText = movie.release_date;
  movieCardInfoDetail1.appendChild(movieCardInfoDetail1Span);

  // 02 - 02 - 02
  let movieCardInfoDetail2 = document.createElement("div");
  movieCardInfoDetail2.className = "movie-card-info-detail";
  movieCardInfo.appendChild(movieCardInfoDetail2);

  let movieCardInfoDetail2Label = document.createElement("label");
  movieCardInfoDetail2Label.innerText = "Vote Count";
  movieCardInfoDetail2.appendChild(movieCardInfoDetail2Label);

  let movieCardInfoDetail2Span = document.createElement("span");
  movieCardInfoDetail2Span.innerText = movie.vote_count;
  movieCardInfoDetail2.appendChild(movieCardInfoDetail2Span);
  return element;
}

function createMovieParagraph(movie) {
  let paragraphContainer = document.createElement("div");
  paragraphContainer.className = "col-8";

  let movieTitle = document.createElement("h1");
  movieTitle.innerText = movie.title;
  movieTitle.className = "movie-title";
  paragraphContainer.appendChild(movieTitle);

  let overview = document.createElement("p");
  overview.innerText = movie.overview;
  overview.className = "movie-overview";
  paragraphContainer.appendChild(overview);

  return paragraphContainer;
}
