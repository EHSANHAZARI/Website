var pagination = {
  index: 1,
  total: 0
};

function onPrevClickHandler() {
  if (pagination.index > 1) {
    pagination.index = pagination.index - 1;
    getNowPlayingn(pagination.index, undefined, true);
  }
}

function onNextClickHandler() {
  if (pagination.index < pagination.total) {
    pagination.index = pagination.index + 1;
    getNowPlayingn(pagination.index, undefined, true);
  }
}

function onFirstClickHandler() {
  pagination.index = 1;
  getNowPlayingn(pagination.index, undefined, true);
}

function onLastClickHandler() {
  pagination.index = pagination.total;
  getNowPlayingn(pagination.index, undefined, true);
}

function generatePageNumbers() {
  let pageNumbersCotainer = document.getElementById("pagenNumbers");
  pageNumbersCotainer.innerHTML = "";

  let startIndex = pagination.index - 5;
  if (startIndex < 1) {
    startIndex = 1;
  }

  for (let i = startIndex; i > 0 && i < pagination.index; i++) {
    let button = document.createElement("button");
    button.innerText = i;
    button.className = "btn btn-blue";
    button.addEventListener(
      "click",
      function() {
        pagination.index = i;
        getNowPlayingn(pagination.index, undefined, true);
      },
      false
    );
    pageNumbersCotainer.appendChild(button);
  }

  let currentButton = document.createElement("button");
  currentButton.innerText = pagination.index;
  currentButton.className = "btn btn-blue btn-disabled";
  pageNumbersCotainer.appendChild(currentButton);

  let endIndex = pagination.index + 5;
  if (endIndex > pagination.total) {
    endIndex = pagination.total;
  }

  for (
    let i = pagination.index + 1;
    i > pagination.index && i < endIndex + 1;
    i++
  ) {
    let button = document.createElement("button");
    button.innerText = i;
    button.className = "btn btn-blue";
    button.addEventListener(
      "click",
      function() {
        pagination.index = i;
        getNowPlayingn(pagination.index, undefined, true);
      },
      false
    );
    pageNumbersCotainer.appendChild(button);
  }
}
