function getNowPlayingn(pageIndex, numberOfMovies, withPagination) {
  let xhr = new XMLHttpRequest();

  xhr.open(
    "GET",
    "https://api.themoviedb.org/3/movie/now_playing?page=" +
      pageIndex +
      "&language=en-US&api_key=" +
      apiKey
  );

  xhr.addEventListener("readystatechange", function() {
    if (this.readyState === this.DONE) {
      let movies = JSON.parse(this.response);
      let container = document.getElementById("latestMovies");
      container.innerHTML = "";

      if (numberOfMovies === undefined) numberOfMovies = movies.results.length;

      for (
        let index = 0;
        index < movies.results.length && index < numberOfMovies;
        index++
      ) {
        const movie = movies.results[index];
        let element = createMovieBox(movie);
        container.appendChild(element);
      }

      if (withPagination) {
        pagination.total = movies.total_pages;
        generatePageNumbers();
      }
    }
  });

  xhr.send();
}

function getMovieDetail(movieId) {
  let xhr = new XMLHttpRequest();

  xhr.open(
    "GET",
    "https://api.themoviedb.org/3/movie/" +
      movieId +
      "?api_key=" +
      apiKey +
      "&language=en-US"
  );

  xhr.addEventListener("readystatechange", function() {
    if (this.readyState === this.DONE) {
      let movie = JSON.parse(this.response);

      let container = document.getElementById("movieDetail");

      let movieBox = createMovieBox(movie);
      container.appendChild(movieBox);

      let paragraphContainer = createMovieParagraph(movie);
      container.appendChild(paragraphContainer);

      getMovieVideos(movieId);
    }
  });

  xhr.send();
}

function getMovieVideos(movieId) {
  let xhr = new XMLHttpRequest();

  xhr.open(
    "GET",
    "https://api.themoviedb.org/3/movie/" +
      movieId +
      "/videos?api_key=" +
      apiKey +
      "&language=en-US"
  );

  xhr.addEventListener("readystatechange", function() {
    if (this.readyState === this.DONE) {
      let videos = JSON.parse(this.response);

      let container = document.getElementById("movieVideos");

      for (let index = 0; index < videos.results.length; index++) {
        const video = videos.results[index];

        var element = document.createElement("div");
        element.className = "col-3";

        let iFrame = document.createElement("iframe");
        iFrame.src = youtubeBaseUrl + video.key;

        element.appendChild(iFrame);

        container.appendChild(element);
      }
    }
  });

  xhr.send();
}

function getMovieDetailObject(movieId) {
  let xhr = new XMLHttpRequest();

  xhr.open(
    "GET",
    "https://api.themoviedb.org/3/movie/" +
      movieId +
      "?api_key=" +
      apiKey +
      "&language=en-US"
  );

  xhr.addEventListener("readystatechange", function() {
    if (this.readyState === this.DONE) {
      debugger;
      let movie = JSON.parse(this.response);

      return movie;
    }
  });

  xhr.send();
}
