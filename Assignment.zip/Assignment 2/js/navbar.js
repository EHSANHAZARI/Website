      function openNav() {
         document.getElementById("openCloseNav").style.width = "250px";
      }

      function closeNav() {
         document.getElementById("openCloseNav").style.width = "0";
      } 

      function getSize(){       
        var mobile = document.getElementById("mobile");
        var desktop = document.getElementById("desktop");
        if(window.matchMedia("(min-width: 768px)").matches)
        {
          mobile.style.display = "none";
          desktop.style.display = "inline-block";
        }
        else 
        {      
          mobile.style.display = "block";
          desktop.style.display = "none";      
        }
      }

      function windowSize(w,h){              
         var left = (screen.width - w) / 2;
         var top = (screen.height - h) / 4;
         window.close();
         window.open('index.html','','width='+w+',height='+h+',top='+top+',left='+left);
      }